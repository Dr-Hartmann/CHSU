﻿window.checkPageOverflow = function (element) {
    return element.scrollHeight > element.clientHeight;
};