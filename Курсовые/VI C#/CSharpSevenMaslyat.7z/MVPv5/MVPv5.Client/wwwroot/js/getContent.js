﻿window.getContent = function (element) {
    return element.innerText;
}